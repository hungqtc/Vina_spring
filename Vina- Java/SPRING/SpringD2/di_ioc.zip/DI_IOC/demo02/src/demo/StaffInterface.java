package demo;

public interface StaffInterface {
	public String work();
}
