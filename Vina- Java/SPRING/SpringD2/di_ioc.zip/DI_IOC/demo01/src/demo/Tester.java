package demo;

public class Tester implements StaffInterface{

	@Override
	public String work() {
		return "Test projects!";
	}

}
