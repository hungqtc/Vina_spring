package demo;

public class Developer implements StaffInterface{

	@Override
	public String work() {
		return "Develop projects!";
	}

}
