package demo;

public class Office {
	private StaffInterface tester;
	private StaffInterface developer;
	
	public StaffInterface getTester() {
		return tester;
	}
	public void setTester(StaffInterface tester) {
		this.tester = tester;
	}
	public StaffInterface getDeveloper() {
		return developer;
	}
	public void setDeveloper(StaffInterface developer) {
		this.developer = developer;
	}
	
}
