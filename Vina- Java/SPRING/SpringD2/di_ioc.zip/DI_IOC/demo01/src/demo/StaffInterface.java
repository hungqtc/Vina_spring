package demo;

public interface StaffInterface {
	public String work();
	// INTERFACE VS ABTRACT CLASS
	// INTERFACE : 100% TRUU TUONG
	// ABSTRACT CLASS : 0-100% TRUU TUONG
	
	
}
