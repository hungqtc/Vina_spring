package edu.vinaenter.controllers.clands;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import edu.vinaenter.constants.UrlConstants;

@Controller
public class ClandHomeController {
	
	@GetMapping(UrlConstants.URL_CLAND_HOME)
	public String home() {
		return "cland.home.index";
	}
	
}
