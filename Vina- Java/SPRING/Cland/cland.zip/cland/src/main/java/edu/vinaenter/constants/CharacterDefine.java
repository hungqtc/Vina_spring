package edu.vinaenter.constants;

public class CharacterDefine {
	
	public static final String[] CHARS = {"<", ">", "(", ")"};
}
