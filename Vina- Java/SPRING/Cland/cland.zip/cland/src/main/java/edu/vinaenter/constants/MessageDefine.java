package edu.vinaenter.constants;

public class MessageDefine {
	
	public static final String MSG_ERR = "Xử lý thất bại!";
	
	public static final String MSG_SUCCESS = "Xử lý thành công!"; 
}
