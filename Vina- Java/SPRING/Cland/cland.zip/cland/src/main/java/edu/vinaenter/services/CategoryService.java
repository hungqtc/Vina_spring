package edu.vinaenter.services;

import java.util.List;

import edu.vinaenter.models.Category;

public interface CategoryService {
	
	List<Category> findAll();
}
