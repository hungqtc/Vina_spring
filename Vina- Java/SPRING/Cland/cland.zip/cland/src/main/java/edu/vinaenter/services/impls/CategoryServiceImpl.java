package edu.vinaenter.services.impls;

import java.util.List;

import org.springframework.stereotype.Service;

import edu.vinaenter.daos.CategoryDao;
import edu.vinaenter.models.Category;
import edu.vinaenter.services.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {
	private CategoryDao catDao;

	@Override
	public List<Category> findAll() {
		return catDao.findAll();
	}

}
