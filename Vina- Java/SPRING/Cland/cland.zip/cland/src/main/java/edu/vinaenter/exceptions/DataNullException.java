package edu.vinaenter.exceptions;


@SuppressWarnings("serial")
public class DataNullException extends Exception {

	public DataNullException(String msg) {
		super(msg);
	}
}
