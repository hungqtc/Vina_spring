package edu.vinaenter.controllers.admins;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.vinaenter.constants.UrlConstants;

@Controller
@RequestMapping(UrlConstants.URL_ADMIN)
public class AdminCatController {


	@GetMapping(UrlConstants.URL_ADMIN_CAT_INDEX)
	public String index() {
		return "cland.admin.cat.index";
	}
	
	@GetMapping(UrlConstants.URL_ADMIN_CAT_ADD)
	public String add() {
		return "cland.admin.cat.add";
	}

}
