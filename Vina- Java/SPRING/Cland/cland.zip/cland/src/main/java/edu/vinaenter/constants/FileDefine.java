package edu.vinaenter.constants;

public class FileDefine {
	public static final String DIR_UPLOAD = "upload";
	
	public static final int SIZE =  100000;
	
}
