package edu.vinaenter.constants;


public class UrlConstants {

    public static final String URL_CLAND_HOME = "/home";

    public static final String URL_ADMIN = "/admin";
    
    public static final String URL_ADMIN_INDEX = "/index";
    
    public static final String URL_ADMIN_CAT_INDEX = "/cat/index";
    
    public static final String URL_ADMIN_CAT_ADD = "/cat/add";
    
    private UrlConstants() {
        throw new InstantiationError("Must not instantiate this class");
    }
}
